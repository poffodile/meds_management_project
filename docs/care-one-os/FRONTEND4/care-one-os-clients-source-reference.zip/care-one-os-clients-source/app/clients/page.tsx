"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import "./clients.css";

type Status = "Active" | "Away" | "Hospital" | "Archived";
type Summary = "All clients" | "Medication due" | "Needs attention" | "Currently away" | "New admission";
type DemoState = "normal" | "loading" | "empty" | "error" | "permission";

type Client = {
  initials: string; name: string; preferred: string; dob: string; age: number; room: string; location: string;
  nhs: string; support: string; allergy: string; reaction: string; status: Status; nextMed: string; due: number;
  medicines: string[]; attention: boolean; selfAdmin: boolean; keyWorker: string; newAdmission: boolean;
  gp: string; pharmacy: string; concern: string; mar: string;
};

const clients: Client[] = [
  { initials:"AF", name:"Adam Fraser", preferred:"Adam", dob:"18 February 1989", age:37, room:"Flat 4", location:"Willow House", nhs:"000 000 1001", support:"Prompting", allergy:"No known allergies", reaction:"None recorded", status:"Active", nextMed:"12:00", due:0, medicines:["Sertraline","Vitamin D"], attention:false, selfAdmin:true, keyWorker:"Morgan Lee", newAdmission:false, gp:"Dr Helen Ward", pharmacy:"Willow Pharmacy", concern:"No open concerns", mar:"Morning medicines recorded at 08:06" },
  { initials:"AB", name:"Aisha Bello", preferred:"Aisha", dob:"14 March 1992", age:34, room:"Flat 2", location:"Willow House", nhs:"000 000 1002", support:"Full support", allergy:"Penicillin", reaction:"Rash and swelling", status:"Active", nextMed:"10:00", due:2, medicines:["Pregabalin","Omeprazole","Paracetamol"], attention:true, selfAdmin:false, keyWorker:"Precious O.", newAdmission:false, gp:"Dr Helen Ward", pharmacy:"Willow Pharmacy", concern:"Low stock: Pregabalin", mar:"Two medicines given at 08:11" },
  { initials:"DO", name:"Daniel Okoro", preferred:"Danny", dob:"30 June 1986", age:40, room:"Room 6", location:"Rosewood Lodge", nhs:"000 000 1003", support:"Full support", allergy:"No known allergies", reaction:"None recorded", status:"Active", nextMed:"12:30", due:0, medicines:["Ramipril","Atorvastatin"], attention:false, selfAdmin:false, keyWorker:"Alex Grant", newAdmission:false, gp:"Dr Nina Shah", pharmacy:"Central Care Pharmacy", concern:"No open concerns", mar:"Morning medicines recorded at 07:52" },
  { initials:"GA", name:"Grace Adeyemi", preferred:"Grace", dob:"9 September 1998", age:27, room:"Flat 1", location:"Meadow View", nhs:"000 000 1004", support:"Independent", allergy:"Ibuprofen", reaction:"Wheezing", status:"Away", nextMed:"18:00", due:0, medicines:["Cetirizine","Salbutamol"], attention:false, selfAdmin:true, keyWorker:"Morgan Lee", newAdmission:false, gp:"Dr Sara Patel", pharmacy:"Meadow Pharmacy", concern:"Away medication pack issued", mar:"Away dose supplied yesterday at 16:20" },
  { initials:"JK", name:"Jamila Khan", preferred:"Mila", dob:"6 January 1994", age:32, room:"Room 3", location:"Rosewood Lodge", nhs:"000 000 1005", support:"Full support", allergy:"No known allergies", reaction:"None recorded", status:"Active", nextMed:"09:30", due:1, medicines:["Metformin","Lansoprazole"], attention:false, selfAdmin:false, keyWorker:"Precious O.", newAdmission:true, gp:"Dr Nina Shah", pharmacy:"Central Care Pharmacy", concern:"Admission medication reconciliation due", mar:"First MAR entry added yesterday" },
  { initials:"MC", name:"Marcus Cole", preferred:"Marcus", dob:"11 November 1984", age:41, room:"Flat 7", location:"Willow House", nhs:"000 000 1006", support:"Prompting", allergy:"Latex", reaction:"Contact rash", status:"Hospital", nextMed:"Not scheduled", due:0, medicines:["Amlodipine","Fluoxetine"], attention:true, selfAdmin:false, keyWorker:"Jamie Reed", newAdmission:false, gp:"Dr Helen Ward", pharmacy:"Willow Pharmacy", concern:"Hospital medicines handover awaiting confirmation", mar:"Hospital transfer recorded at 06:45" },
  { initials:"NW", name:"Noah Williams", preferred:"Noah", dob:"27 December 1996", age:29, room:"Flat 5", location:"Meadow View", nhs:"000 000 1007", support:"Full support", allergy:"No known allergies", reaction:"None recorded", status:"Active", nextMed:"10:00", due:3, medicines:["Sodium valproate","Folic acid"], attention:true, selfAdmin:false, keyWorker:"Alex Grant", newAdmission:false, gp:"Dr Sara Patel", pharmacy:"Meadow Pharmacy", concern:"Three medicines overdue by 18 minutes", mar:"PRN outcome review completed at 08:32" },
  { initials:"SM", name:"Sofia Martins", preferred:"Sofia", dob:"19 April 1990", age:36, room:"Flat 3", location:"Willow House", nhs:"000 000 1008", support:"Prompting", allergy:"No known allergies", reaction:"None recorded", status:"Active", nextMed:"14:00", due:0, medicines:["Levothyroxine","Ferrous sulfate"], attention:false, selfAdmin:true, keyWorker:"Jamie Reed", newAdmission:true, gp:"Dr Helen Ward", pharmacy:"Willow Pharmacy", concern:"No open concerns", mar:"Self-administration confirmed at 07:40" },
];

const nav = ["Today", "People", "Medicines", "Operations", "Assurance"];
const locations = ["All locations", "Willow House", "Rosewood Lodge", "Meadow View"];

export default function ClientsPage() {
  const [query,setQuery] = useState("");
  const [summary,setSummary] = useState<Summary>("All clients");
  const [location,setLocation] = useState("All locations");
  const [status,setStatus] = useState("All statuses");
  const [support,setSupport] = useState("All support levels");
  const [keyWorker,setKeyWorker] = useState("All key workers");
  const [allergy,setAllergy] = useState(false);
  const [selfAdmin,setSelfAdmin] = useState(false);
  const [attention,setAttention] = useState(false);
  const [filterOpen,setFilterOpen] = useState(false);
  const [selected,setSelected] = useState<Client|null>(null);
  const [offline,setOffline] = useState(false);
  const [demoState,setDemoState] = useState<DemoState>("normal");
  const listRef = useRef<HTMLDivElement>(null);

  const closePreview = (fromHistory=false) => {
    setSelected(null);
    if (!fromHistory && window.history.state?.clientPreview) window.history.back();
  };
  const openPreview = (client: Client) => {
    setSelected(client);
    window.history.pushState({clientPreview:true}, "", `${window.location.pathname}${window.location.search}`);
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") { setFilterOpen(false); if (selected) closePreview(); } };
    const onPop = () => setSelected(null);
    window.addEventListener("keydown",onKey); window.addEventListener("popstate",onPop);
    return () => { window.removeEventListener("keydown",onKey); window.removeEventListener("popstate",onPop); };
  },[selected]);

  const visible = useMemo(() => {
    if (demoState === "empty") return [];
    const term=query.trim().toLowerCase();
    return clients.filter(c => {
      const searchable=[c.name,c.preferred,c.room,c.location,c.nhs,...c.medicines].join(" ").toLowerCase();
      const summaryMatch = summary === "All clients" || (summary === "Medication due" && c.due>0) || (summary === "Needs attention" && c.attention) || (summary === "Currently away" && c.status==="Away") || (summary === "New admission" && c.newAdmission);
      return (!term || searchable.includes(term)) && summaryMatch && (location==="All locations" || c.location===location) && (status==="All statuses" || c.status===status) && (support==="All support levels" || c.support===support) && (keyWorker==="All key workers" || c.keyWorker===keyWorker) && (!allergy || c.allergy!=="No known allergies") && (!selfAdmin || c.selfAdmin) && (!attention || c.attention);
    }).sort((a,b)=>a.name.localeCompare(b.name));
  },[query,summary,location,status,support,keyWorker,allergy,selfAdmin,attention,demoState]);

  const clearFilters=()=>{setQuery("");setSummary("All clients");setLocation("All locations");setStatus("All statuses");setSupport("All support levels");setKeyWorker("All key workers");setAllergy(false);setSelfAdmin(false);setAttention(false);setDemoState("normal");};
  const grouped=visible.reduce<Record<string,Client[]>>((acc,c)=>{(acc[c.name[0]]??=[]).push(c);return acc;},{});
  const counts:Record<Summary,number>={"All clients":clients.length,"Medication due":clients.filter(c=>c.due>0).length,"Needs attention":clients.filter(c=>c.attention).length,"Currently away":clients.filter(c=>c.status==="Away").length,"New admission":clients.filter(c=>c.newAdmission).length};

  return <main className="app-shell clients-shell">
    <aside className="sidebar" aria-label="Primary navigation">
      <Link className="brand clients-brand" href="/"><span className="brand-mark" aria-hidden="true">C1</span><span><strong>Care One</strong><small>OS</small></span></Link>
      <nav className="nav-list">{nav.map((item,i)=><Link key={item} href={item==="Today"?"/":item==="People"?"/clients":"#"} className={`nav-item ${item==="People"?"active":""}`}><span className="nav-icon" aria-hidden="true">{["⌂","◎","+","↗","◇"][i]}</span>{item}{item==="Operations"&&<span className="nav-count">3</span>}</Link>)}</nav>
      <div className="sidebar-bottom"><button className="nav-item"><span className="nav-icon">?</span>Help &amp; support</button><button className="profile-button"><span className="avatar dark">PO</span><span><strong>Precious O.</strong><small>Support worker</small></span><span>···</span></button></div>
    </aside>
    <section className="workspace">
      <header className="topbar"><div className="context-selectors"><button><span className="context-dot"/>Rosewood Supported Living <span>⌄</span></button><span className="separator"/><button>Willow House <span>⌄</span></button></div><div className="top-actions"><label className="search"><span>⌕</span><input aria-label="Search people, medicines and records" placeholder="Search"/><kbd>⌘ K</kbd></label><button className="icon-button" aria-label="Messages">◌<span className="unread"/></button><button className="icon-button" aria-label="Notifications">♢<span className="unread"/></button></div></header>
      {offline&&<div className="offline-banner" role="status"><span>↯</span><strong>You are offline.</strong> Showing the most recently synced client records.<button onClick={()=>setOffline(false)} aria-label="Dismiss offline message">×</button></div>}
      <div className="page clients-page">
        <header className="clients-heading"><div><p className="eyebrow">People we support</p><h1>Clients</h1><p className="subtitle">People supported across your assigned locations</p></div><div className="heading-controls"><label>Location<select value={location} onChange={e=>setLocation(e.target.value)}>{locations.map(x=><option key={x}>{x}</option>)}</select></label><span className="visible-count" aria-live="polite"><strong>{visible.length}</strong> visible</span></div></header>
        <div className="client-toolbar"><label className="client-search"><span aria-hidden="true">⌕</span><span className="sr-only">Search clients</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name, room, NHS number or medication"/>{query&&<button onClick={()=>setQuery("")} aria-label="Clear search">×</button>}</label><button className="filter-trigger" onClick={()=>setFilterOpen(true)} aria-expanded={filterOpen}><span>☷</span> Filters</button><label className="demo-control">View state<select value={demoState} onChange={e=>setDemoState(e.target.value as DemoState)}><option value="normal">Normal</option><option value="loading">Loading</option><option value="empty">No clients</option><option value="error">Error</option><option value="permission">No permission</option></select></label><button className="offline-toggle" onClick={()=>setOffline(v=>!v)}>Offline demo</button></div>
        <section className="summary-row" aria-label="Client summary filters">{(Object.keys(counts) as Summary[]).map(item=><button key={item} className={summary===item?"active":""} aria-pressed={summary===item} onClick={()=>setSummary(item)}><span>{item}</span><strong>{counts[item]}</strong></button>)}</section>
        <div className="directory-layout">
          <aside className={`filter-panel ${filterOpen?"open":""}`} aria-label="Client filters"><div className="filter-panel-head"><div><p className="eyebrow">Refine directory</p><h2>Filters</h2></div><button onClick={()=>setFilterOpen(false)} aria-label="Close filters">×</button></div><label>Location<select value={location} onChange={e=>setLocation(e.target.value)}>{locations.map(x=><option key={x}>{x}</option>)}</select></label><label>Status<select value={status} onChange={e=>setStatus(e.target.value)}><option>All statuses</option><option>Active</option><option>Away</option><option>Hospital</option><option>Archived</option></select></label><label>Medication support<select value={support} onChange={e=>setSupport(e.target.value)}><option>All support levels</option><option>Independent</option><option>Prompting</option><option>Full support</option></select></label><label>Assigned key worker<select value={keyWorker} onChange={e=>setKeyWorker(e.target.value)}><option>All key workers</option><option>Precious O.</option><option>Morgan Lee</option><option>Alex Grant</option><option>Jamie Reed</option></select></label><label className="check"><input type="checkbox" checked={allergy} onChange={e=>setAllergy(e.target.checked)}/><span>Allergy recorded</span></label><label className="check"><input type="checkbox" checked={selfAdmin} onChange={e=>setSelfAdmin(e.target.checked)}/><span>Self-administering</span></label><label className="check"><input type="checkbox" checked={attention} onChange={e=>setAttention(e.target.checked)}/><span>Needs attention</span></label><div className="filter-actions"><button onClick={clearFilters}>Clear filters</button><button className="apply" onClick={()=>setFilterOpen(false)}>Show {visible.length} clients</button></div></aside>
          {filterOpen&&<button className="drawer-scrim" aria-label="Close filters" onClick={()=>setFilterOpen(false)}/>} 
          <section className="client-list-panel" aria-label="Client directory" ref={listRef}>
            <div className="list-head"><span>Client</span><span>Support &amp; allergies</span><span>Status</span><span>Next medication</span><span>Due</span><span/></div>
            {demoState==="loading"?<div className="skeleton-list" aria-label="Loading clients">{[1,2,3,4,5].map(x=><div key={x}><i/><span/><span/><span/></div>)}</div>:demoState==="error"?<State icon="!" title="Client records could not be loaded" text="There was a problem connecting to the records service." action="Retry" onAction={()=>setDemoState("normal")}/>:demoState==="permission"?<State icon="⌾" title="You do not have permission to view clients" text="Ask your manager to check your assigned locations and access role."/>:visible.length===0?<State icon="⌕" title={query?"No search results":"No clients in this view"} text={query?`No clients match “${query}”.`:"There are no clients matching the selected filters."} action={query?"Clear search":"Clear filters"} onAction={query?()=>setQuery(""):clearFilters}/>:Object.entries(grouped).map(([letter,items])=><section className="alpha-group" key={letter} aria-labelledby={`group-${letter}`}><h2 id={`group-${letter}`}>{letter}</h2>{items.map(c=><button className="client-row" key={c.name} onClick={()=>openPreview(c)} aria-label={`${c.name}, ${c.status}, ${c.due} medicines due. Open quick preview`}><span className="client-identity"><span className="avatar">{c.initials}</span><span><strong>{c.name}</strong>{c.preferred!==c.name.split(" ")[0]&&<em>Prefers {c.preferred}</em>}<small>{c.age} years · {c.room} · {c.location}</small></span></span><span className="support-cell"><strong>{c.support}</strong><small className={c.allergy!=="No known allergies"?"allergy-warning":""}>{c.allergy!=="No known allergies"?"⚠ ":"✓ "}{c.allergy}</small></span><span><span className={`status-label ${c.status.toLowerCase()}`}>{c.status}</span></span><span className="med-time"><strong>{c.nextMed}</strong><small>{c.medicines[0]}</small></span><span className={`due-count ${c.due>0?"has-due":""}`}><strong>{c.due}</strong><small>due</small></span><span className="row-arrow" aria-hidden="true">›</span></button>)}</section>)}
          </section>
        </div>
      </div>
      <nav className="mobile-nav" aria-label="Mobile navigation"><Link href="/"><span>⌂</span>Today</Link><Link href="/clients" className="active"><span>◎</span>People</Link><button><span>＋</span>Round</button><button><span>◌</span>Messages</button><button><span>···</span>More</button></nav>
    </section>
    {selected&&<><button className="preview-scrim" aria-label="Close client preview" onClick={()=>closePreview()}/><aside className="quick-preview" role="dialog" aria-modal="true" aria-labelledby="preview-title"><header><p>Client quick preview</p><button onClick={()=>closePreview()} aria-label="Close client preview">×</button></header><div className="preview-person"><span className="avatar large">{selected.initials}</span><div><h2 id="preview-title">{selected.name}</h2>{selected.preferred!==selected.name.split(" ")[0]&&<p>Prefers {selected.preferred}</p>}<span className={`status-label ${selected.status.toLowerCase()}`}>{selected.status}</span></div></div><dl className="preview-details"><div><dt>Date of birth</dt><dd>{selected.dob}</dd></div><div><dt>Home</dt><dd>{selected.room}, {selected.location}</dd></div><div><dt>Medication support</dt><dd>{selected.support}{selected.selfAdmin?" · Self-administering":""}</dd></div><div className="wide"><dt>Allergies and reactions</dt><dd className={selected.allergy!=="No known allergies"?"danger-text":""}>{selected.allergy} · {selected.reaction}</dd></div></dl><section className="preview-card"><p className="eyebrow">Medication schedule</p><div><span>Next scheduled</span><strong>{selected.nextMed}</strong></div><small>{selected.medicines.join(" · ")}</small></section><section className="preview-card"><p className="eyebrow">Open medication concerns</p><strong className={selected.attention?"danger-text":""}>{selected.attention?"⚠ ":"✓ "}{selected.concern}</strong></section><section className="contacts"><div><span>GP</span><strong>{selected.gp}</strong></div><div><span>Pharmacy</span><strong>{selected.pharmacy}</strong></div></section><section className="mar-activity"><p className="eyebrow">Recent MAR activity</p><div><span>✓</span><p><strong>{selected.mar}</strong><small>Recorded in the demo MAR</small></p></div></section><div className="preview-actions">{selected.name==="Aisha Bello"?<><Link className="primary-button profile-link" href="/clients/aisha-bello">Open full profile</Link><Link href="/clients/aisha-bello?tab=Medications">View medications</Link><Link href="/clients/aisha-bello?tab=MAR%20history">View MAR</Link><Link href="/clients/aisha-bello?tab=Care%20notes">Add handover note</Link></>:<><button className="primary-button" onClick={()=>alert(`${selected.name}'s full profile is not included in this prototype yet.`)}>Profile not yet built</button><button onClick={()=>alert(`${selected.name}'s medication record is not included in this prototype yet.`)}>View medications</button><button onClick={()=>alert(`${selected.name}'s MAR is not included in this prototype yet.`)}>View MAR</button><button onClick={()=>alert(`${selected.name}'s handover record is not included in this prototype yet.`)}>Add handover note</button></>}</div></aside></>}
  </main>;
}

function State({icon,title,text,action,onAction}:{icon:string;title:string;text:string;action?:string;onAction?:()=>void}) { return <div className="directory-state" role="status"><span>{icon}</span><strong>{title}</strong><p>{text}</p>{action&&<button onClick={onAction}>{action}</button>}</div>; }
