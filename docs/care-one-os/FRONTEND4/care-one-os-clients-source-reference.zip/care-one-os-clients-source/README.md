# Care One OS Clients source

This package contains the exact React/Next.js source used by the live Clients section.

## Files

- `app/clients/page.tsx` — searchable client directory, filters and quick-preview drawer.
- `app/clients/clients.css` — complete client-directory styling and responsive layout.
- `app/clients/aisha-bello/page.tsx` — Aisha Bello's full profile and every profile tab: Overview, Medications, PRN protocols, Allergies, MAR history, Care notes, Documents and Audit history.
- `app/clients/aisha-bello/profile.css` — complete styling for the profile and every tab, including mobile layouts, drawers, forms and status states.
- `app/globals.css` — shared site design tokens and global styles required by the pages.
- `app/layout.tsx` — Next.js application layout and font setup.

## How to use it

Copy the `app` folder into a Next.js App Router project while preserving the folder structure. The pages use React client components and import their CSS files directly.

The current data is prototype data held inside the React files. Forms, filters, tab navigation and prototype downloads work in the browser, but permanent clinical storage requires connection to your Laravel/API backend and database.

If passing this package to Claude or another coding assistant, ask it to preserve the visual design and component behaviour while splitting the large Aisha profile file into reusable components before connecting live APIs.
