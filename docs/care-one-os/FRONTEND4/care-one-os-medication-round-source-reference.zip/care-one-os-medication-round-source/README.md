# Care One OS Medication Round source

This package contains the exact React/Next.js source used by the live Medication Round page.

## Files

- `app/round/page.tsx` — complete Medication Round interface and prototype interactions.
- `app/round/round.css` — complete responsive styling for desktop and mobile.
- `app/globals.css` — shared site design tokens and global styling.
- `app/layout.tsx` — Next.js application layout and font setup.

## Included behaviour

- Round status and progress
- Person selection and status filters
- Medicine cards and administration instructions
- Given and not-given outcomes
- Reason and notes for non-administration
- Controlled-drug witness workflow
- Stock information
- Confirmation and audit timeline
- Round completion controls
- Responsive mobile navigation and layout

## Using this with Codex

Copy the `app` folder into a Next.js App Router project while preserving the folder structure. If adapting it to the existing Care One OS Laravel application, use the page as the visual and interaction reference, split it into reusable React components, replace the prototype arrays with Inertia props or API data, and connect every administration action to the existing Laravel medication, MAR, stock, witness and audit services.

The supplied page uses local prototype state. It demonstrates the workflow but does not permanently save clinical records until connected to the real backend.
