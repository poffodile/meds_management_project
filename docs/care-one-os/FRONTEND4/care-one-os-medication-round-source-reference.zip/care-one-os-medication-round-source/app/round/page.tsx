"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import "./round.css";

type PersonState = "Due now" | "Attention" | "Completed" | "Upcoming";
type Outcome = "Given" | "Not given" | null;
type RecordedDetail = { outcome: Exclude<Outcome, null>; reason?: string; note?: string; time: string; witness?: string };
type AuditEntry = { id: number; time: string; title: string; detail: string; actor: string };

const people: { id: number; initials: string; name: string; home: string; time: string; medicines: number; state: PersonState; note: string }[] = [
  { id: 1, initials: "AM", name: "Amina Malik", home: "Flat 2", time: "08:00", medicines: 4, state: "Due now", note: "1 controlled medicine" },
  { id: 2, initials: "JT", name: "Jordan Taylor", home: "Flat 5", time: "08:00", medicines: 3, state: "Attention", note: "Medication unavailable" },
  { id: 3, initials: "SK", name: "Samira Khan", home: "Flat 1", time: "08:30", medicines: 2, state: "Due now", note: "PRN review at 10:30" },
  { id: 4, initials: "DO", name: "Daniel Okafor", home: "Flat 4", time: "07:30", medicines: 5, state: "Completed", note: "Completed at 07:42" },
  { id: 5, initials: "LB", name: "Leo Bennett", home: "Flat 3", time: "08:45", medicines: 2, state: "Upcoming", note: "Take with food" },
];

const medicines = [
  { id: 1, name: "Metformin", detail: "500 mg · tablet · oral", instruction: "Give ONE tablet with or just after food", stock: "28 tablets", flag: "With food" },
  { id: 2, name: "Amlodipine", detail: "5 mg · tablet · oral", instruction: "Give ONE tablet", stock: "14 tablets", flag: "Routine" },
  { id: 3, name: "Pregabalin", detail: "75 mg · capsule · oral", instruction: "Give ONE capsule. Do not crush.", stock: "3 capsules", flag: "Controlled drug" },
  { id: 4, name: "Colecalciferol", detail: "1,000 units · capsule · oral", instruction: "Give ONE capsule", stock: "21 capsules", flag: "Routine" },
];

export default function MedicationRound() {
  const [selectedPerson, setSelectedPerson] = useState(1);
  const [filter, setFilter] = useState("All");
  const [records, setRecords] = useState<Record<number, RecordedDetail>>({});
  const [showReason, setShowReason] = useState<number | null>(null);
  const [reason, setReason] = useState("");
  const [reasonNote, setReasonNote] = useState("");
  const [witness, setWitness] = useState("");
  const [witnessConfirmed, setWitnessConfirmed] = useState(false);
  const [auditOpen, setAuditOpen] = useState(true);
  const [prnOpen, setPrnOpen] = useState(false);
  const [prnReason, setPrnReason] = useState("");
  const [prnScore, setPrnScore] = useState("");
  const [prnDose, setPrnDose] = useState("");
  const [prnNote, setPrnNote] = useState("");
  const [prnRecorded, setPrnRecorded] = useState(false);
  const [prnTime, setPrnTime] = useState("");
  const [showComplete, setShowComplete] = useState(false);
  const [completionConfirmed, setCompletionConfirmed] = useState(false);
  const [personCompleted, setPersonCompleted] = useState(false);
  const [audit, setAudit] = useState<AuditEntry[]>([
    { id: 1, time: "07:56", title: "Round opened", detail: "Morning round opened for Amina Malik", actor: "Precious O." },
    { id: 2, time: "07:54", title: "Record checked", detail: "Current prescription and allergy information reviewed", actor: "System" },
  ]);
  const person = people.find((item) => item.id === selectedPerson)!;
  const visiblePeople = useMemo(() => people.filter((item) => filter === "All" || item.state === filter), [filter]);
  const completed = Object.keys(records).length;
  const givenCount = Object.values(records).filter((item) => item.outcome === "Given").length;
  const notGivenRecords = Object.entries(records).filter(([, item]) => item.outcome === "Not given");
  const outstandingCount = medicines.length - completed;
  const now = () => new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const addAudit = (title: string, detail: string, actor = "Precious O.") => setAudit((current) => [{ id: Date.now(), time: now(), title, detail, actor }, ...current]);

  const record = (id: number, outcome: Outcome) => {
    if (outcome === "Not given") { setShowReason(id); return; }
    const medicine = medicines.find((item) => item.id === id)!;
    if (medicine.flag === "Controlled drug" && !witnessConfirmed) return;
    const detail: RecordedDetail = { outcome: "Given", time: now(), ...(medicine.flag === "Controlled drug" ? { witness } : {}) };
    setRecords((current) => ({ ...current, [id]: detail }));
    addAudit("Medicine recorded as given", `${medicine.name} ${medicine.detail}${detail.witness ? ` · witnessed by ${detail.witness}` : ""}`);
  };
  const saveReason = () => {
    if (!showReason || !reason) return;
    const medicine = medicines.find((item) => item.id === showReason)!;
    setRecords((current) => ({ ...current, [showReason]: { outcome: "Not given", reason, note: reasonNote.trim() || undefined, time: now() } }));
    addAudit("Medicine recorded as not given", `${medicine.name} · ${reason}${reasonNote.trim() ? ` · Note: ${reasonNote.trim()}` : ""}`);
    setShowReason(null); setReason(""); setReasonNote("");
  };
  const changeRecord = (id: number) => {
    const medicine = medicines.find((item) => item.id === id)!;
    const previous = records[id];
    addAudit("Administration record reopened", `${medicine.name} changed from “${previous.outcome}” for correction. Original entry retained in history.`);
    setRecords((current) => { const next = { ...current }; delete next[id]; return next; });
  };
  const recordPrn = () => {
    if (!prnReason || !prnScore || !prnDose) return;
    setPrnRecorded(true);
    setPrnTime(now());
    addAudit("PRN medicine recorded as given", `Paracetamol ${prnDose} · ${prnReason} · pain score ${prnScore}/10${prnNote.trim() ? ` · Note: ${prnNote.trim()}` : ""} · outcome review due in 2 hours`);
  };
  const completePerson = () => {
    if (outstandingCount || !completionConfirmed) return;
    setPersonCompleted(true);
    addAudit("Person medication round completed", `${person.name} completed with ${givenCount} given and ${notGivenRecords.length} not given${prnRecorded ? " · PRN follow-up task created" : ""}`);
  };
  const continueToNextPerson = () => {
    setShowComplete(false); setPersonCompleted(false); setCompletionConfirmed(false);
    setSelectedPerson(2); setRecords({}); setPrnRecorded(false); setPrnOpen(false); setPrnReason(""); setPrnScore(""); setPrnDose(""); setPrnNote(""); setWitness(""); setWitnessConfirmed(false);
  };

  return <main className="round-shell">
    <aside className="round-side">
      <Link href="/" className="round-brand"><span>C1</span><strong>Care One <small>OS</small></strong></Link>
      <nav><Link href="/">⌂ Today</Link><a className="active">＋ Medication round</a><a>◎ People</a><a>▣ MAR records</a><a>◇ Stock</a></nav>
      <div className="round-user"><b>PO</b><span><strong>Precious O.</strong><small>Support worker</small></span></div>
    </aside>

    <section className="round-workspace">
      <header className="round-topbar">
        <Link href="/" aria-label="Back to dashboard">←</Link>
        <div><strong>Morning medication round</strong><small>Rosewood · Willow House</small></div>
        <span className="sync">● Records synced</span>
        <button aria-label="More options">•••</button>
      </header>

      <div className="round-page">
        <section className="round-heading">
          <div><p className="round-eyebrow">Tuesday, 4 August · 07:00–10:00</p><h1>Morning round</h1><p>Record each medicine immediately after the person has taken it.</p></div>
          <div className="round-progress"><span><b>{completed}</b> of {medicines.length} medicines recorded</span><i><b style={{ width: `${completed / medicines.length * 100}%` }} /></i></div>
        </section>

        <section className="round-alert"><b>!</b><div><strong>Safety check</strong><span>Confirm the right person, medicine, dose, route, time and right to refuse before recording.</span></div><button>View checks</button></section>

        <div className="round-layout">
          <aside className="round-queue">
            <div className="queue-head"><div><p className="round-eyebrow">Round queue</p><h2>People</h2></div><span>6 due</span></div>
            <label className="round-search">⌕ <input placeholder="Search people" aria-label="Search people" /></label>
            <div className="round-filters">{["All", "Due now", "Attention", "Completed"].map(item => <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>{item}</button>)}</div>
            <div className="queue-list">{visiblePeople.map(item => <button key={item.id} className={selectedPerson === item.id ? "queue-person selected" : "queue-person"} onClick={() => setSelectedPerson(item.id)}>
              <b className="round-avatar">{item.initials}</b><span><strong>{item.name}</strong><small>{item.home} · {item.medicines} medicines</small><em>{item.note}</em></span><time>{item.time}<small className={item.state.toLowerCase().replace(" ", "-")}>{item.state}</small></time>
            </button>)}</div>
          </aside>

          <section className="medication-work">
            <article className="person-banner">
              <b className="person-avatar">{person.initials}</b><div><p className="round-eyebrow">Selected person</p><h2>{person.name}</h2><span>DOB 14 May 1982 · NHS ending 4821 · {person.home}</span></div>
              <div className="allergy"><small>Allergy</small><strong>Penicillin</strong><span>Reaction: rash</span></div>
              <button>View profile</button>
            </article>

            <div className="medication-summary"><span><b>08:00</b> Scheduled time</span><span><b>{medicines.length}</b> Medicines</span><span><b>Oral</b> Primary route</span><span><b>Support</b> Administration level</span></div>

            <div className="medicine-title"><div><p className="round-eyebrow">Medication administration</p><h2>Medicines due now</h2></div><span>{completed}/{medicines.length} recorded</span></div>

            <div className="medicine-list">{medicines.map((med, index) => <article className={records[med.id] ? "medicine-card recorded" : "medicine-card"} key={med.id}>
              <header><span className="medicine-number">{records[med.id] ? "✓" : index + 1}</span><div><h3>{med.name}</h3><p>{med.detail}</p></div><span className={med.flag === "Controlled drug" ? "med-flag cd" : "med-flag"}>{med.flag}</span><button aria-label={`More information about ${med.name}`}>ⓘ</button></header>
              <div className="medicine-instruction"><small>Directions</small><strong>{med.instruction}</strong></div>
              <div className="medicine-meta"><span>Stock after dose: <b>{med.stock}</b></span><span>Last given: <b>Yesterday 08:04</b></span></div>
              {med.flag === "Controlled drug" && !records[med.id] && <section className="witness-check"><div><span>◎</span><p><strong>Second-person confirmation required</strong><small>The witness must independently check the medicine, dose and remaining balance.</small></p></div><label>Witness<select value={witness} onChange={(e) => { setWitness(e.target.value); setWitnessConfirmed(false); }}><option value="">Select trained colleague</option><option>Morgan Reed</option><option>Amara Johnson</option><option>Lewis Grant</option></select></label><button disabled={!witness} className={witnessConfirmed ? "confirmed" : ""} onClick={() => { setWitnessConfirmed(true); addAudit("Witness confirmed", `${witness} independently confirmed ${med.name}, the dose and stock balance`, witness); }}>{witnessConfirmed ? "✓ Witness confirmed" : "Confirm witness"}</button></section>}
              {records[med.id] ? <div className={`recorded-result detailed ${records[med.id].outcome === "Not given" ? "not-given" : ""}`}><span>{records[med.id].outcome === "Given" ? "✓" : "!"}</span><div><strong>{records[med.id].outcome}</strong><small>{records[med.id].reason && <b>Reason: {records[med.id].reason}</b>}{records[med.id].note && <> · Note: {records[med.id].note}</>}{records[med.id].witness && <> · Witness: {records[med.id].witness}</>}</small><em>Recorded at {records[med.id].time} by Precious O.</em></div><button onClick={() => changeRecord(med.id)}>Change</button></div> : <div className="medicine-actions"><button className="give" disabled={med.flag === "Controlled drug" && !witnessConfirmed} onClick={() => record(med.id, "Given")}>✓ Confirm given</button><button onClick={() => record(med.id, "Not given")}>Not given</button></div>}
            </article>)}</div>

            <section className="prn-panel">
              <header><div><p className="round-eyebrow">When required medicine</p><h2>PRN available</h2><span>Only administer when the person needs it and the protocol conditions are met.</span></div><span className="prn-count">1 available</span></header>
              <article className={prnRecorded ? "prn-card completed" : "prn-card"}>
                <div className="prn-medicine"><span className="medicine-number">{prnRecorded ? "✓" : "P"}</span><div><h3>Paracetamol</h3><p>500 mg tablets · oral · give ONE or TWO tablets when required for pain</p></div><span className="med-flag">PRN protocol</span></div>
                <div className="prn-safety"><span><small>Last administered</small><strong>04:00 · 1,000 mg</strong></span><span className="safe"><small>Minimum interval</small><strong>✓ 4 hours met</strong></span><span><small>Last 24 hours</small><strong>3,000 mg of 4,000 mg</strong></span><span><small>Next review</small><strong>2 hours after dose</strong></span></div>
                {!prnOpen && !prnRecorded && <button className="start-prn" onClick={() => setPrnOpen(true)}>Start PRN assessment →</button>}
                {prnOpen && !prnRecorded && <div className="prn-form">
                  <div className="prn-form-heading"><div><p className="round-eyebrow">Step 1 of 2</p><h3>Record why it is needed</h3></div><button onClick={() => setPrnOpen(false)}>×</button></div>
                  <label>Reason or symptom<select value={prnReason} onChange={(e) => setPrnReason(e.target.value)}><option value="">Select reason</option><option>Headache</option><option>Muscular pain</option><option>Joint pain</option><option>Dental pain</option><option>Other pain</option></select></label>
                  <label>Pain score before administration<div className="score-options">{["0", "2", "4", "6", "8", "10"].map(score => <button type="button" key={score} className={prnScore === score ? "selected" : ""} onClick={() => setPrnScore(score)}>{score}</button>)}</div><small>0 = no pain · 10 = worst pain imaginable</small></label>
                  <label>Dose to administer<select value={prnDose} onChange={(e) => setPrnDose(e.target.value)}><option value="">Select prescribed dose</option><option>500 mg · ONE tablet</option><option>1,000 mg · TWO tablets</option></select></label>
                  {prnDose === "1,000 mg · TWO tablets" && <div className="dose-warning"><b>!</b><span><strong>Maximum daily dose reached</strong><small>This dose would bring the total to 4,000 mg in 24 hours. Do not give any further paracetamol before 04:00 tomorrow.</small></span></div>}
                  <label>Supporting note (optional)<textarea value={prnNote} onChange={(e) => setPrnNote(e.target.value)} placeholder="Describe the symptom, location or support already tried" /></label>
                  <div className="prn-review"><span>◷</span><div><strong>Outcome review will be due in 2 hours</strong><small>A follow-up task will be created to record whether the medicine was effective.</small></div></div>
                  <div className="prn-actions"><button onClick={() => setPrnOpen(false)}>Cancel</button><button disabled={!prnReason || !prnScore || !prnDose} onClick={recordPrn}>Confirm PRN given</button></div>
                </div>}
                {prnRecorded && <div className="prn-result"><span>✓</span><div><strong>PRN given · {prnDose}</strong><p>Reason: {prnReason} · pain score before: {prnScore}/10{prnNote.trim() ? ` · Note: ${prnNote.trim()}` : ""}</p><small>Recorded at {prnTime} by Precious O. · Effectiveness review due in 2 hours</small></div><button onClick={() => { setPrnRecorded(false); setPrnOpen(true); addAudit("PRN record reopened", "Paracetamol PRN entry reopened for correction. Original entry retained in history."); }}>Change</button></div>}
              </article>
            </section>

            <section className="audit-panel"><button className="audit-heading" onClick={() => setAuditOpen((current) => !current)} aria-expanded={auditOpen}><div><p className="round-eyebrow">Permanent record</p><h2>Activity and change log</h2></div><span>{audit.length} entries {auditOpen ? "⌃" : "⌄"}</span></button>{auditOpen && <div className="audit-list">{audit.map((entry) => <article key={entry.id}><time>{entry.time}</time><i /><div><strong>{entry.title}</strong><p>{entry.detail}</p><small>{entry.actor}</small></div></article>)}</div>}</section>

            <footer className="round-complete"><div><strong>{completed === medicines.length ? "All medicines recorded" : `${medicines.length - completed} medicines still require an outcome`}</strong><span>{completed === medicines.length ? "Review and sign off this person before continuing." : "Complete every item before moving to the next person."}</span></div><button onClick={() => setShowComplete(true)}>{completed === medicines.length ? "Review & complete →" : "Review outstanding →"}</button></footer>
          </section>
        </div>
      </div>

      <nav className="round-mobile-nav"><Link href="/">⌂<small>Today</small></Link><a className="active">＋<small>Round</small></a><a>◎<small>People</small></a><a>•••<small>More</small></a></nav>
    </section>

    {showReason && <div className="reason-backdrop" role="dialog" aria-modal="true" aria-labelledby="reason-title"><section className="reason-sheet"><button className="close-reason" onClick={() => setShowReason(null)}>×</button><p className="round-eyebrow">Administration outcome</p><h2 id="reason-title">Why was this medicine not given?</h2><p>Select the factual reason. The reason and note will remain visible on the record and in its change history.</p><div className="reason-options">{["Person refused", "Person asleep", "Person away", "Medicine unavailable", "Clinical instruction to omit", "Other"].map(item => <button key={item} className={reason === item ? "selected" : ""} onClick={() => setReason(item)}>{item}<span>{reason === item ? "●" : "○"}</span></button>)}</div><label>Additional note (optional)<textarea value={reasonNote} onChange={(e) => setReasonNote(e.target.value)} placeholder="Add clear, factual information" /></label><div className="reason-actions"><button onClick={() => setShowReason(null)}>Cancel</button><button disabled={!reason} onClick={saveReason}>Record not given</button></div></section></div>}
    {showComplete && <div className="complete-backdrop" role="dialog" aria-modal="true" aria-labelledby="complete-title"><section className="complete-sheet">
      {!personCompleted ? <>
        <header><button onClick={() => setShowComplete(false)} aria-label="Close completion review">←</button><div><p className="round-eyebrow">Final safety review</p><h2 id="complete-title">Complete {person.name}</h2><span>Check every outcome before signing off and moving to the next person.</span></div><b className="complete-person-avatar">{person.initials}</b></header>
        <div className="complete-allergy"><b>!</b><span><small>Known allergy</small><strong>Penicillin · reaction: rash</strong></span></div>
        <div className="completion-stats"><article><small>Scheduled</small><strong>{medicines.length}</strong><span>medicines</span></article><article><small>Given</small><strong>{givenCount}</strong><span>recorded</span></article><article><small>Not given</small><strong>{notGivenRecords.length}</strong><span>with reasons</span></article><article><small>Outstanding</small><strong className={outstandingCount ? "warning" : ""}>{outstandingCount}</strong><span>require action</span></article></div>
        <section className="completion-block"><div className="completion-block-title"><div><p className="round-eyebrow">Administration summary</p><h3>Scheduled medicines</h3></div><span>{completed}/{medicines.length} complete</span></div><div className="completion-meds">{medicines.map((medicine) => <article key={medicine.id}><span className={records[medicine.id] ? records[medicine.id].outcome === "Given" ? "complete-given" : "complete-omitted" : "complete-missing"}>{records[medicine.id] ? records[medicine.id].outcome === "Given" ? "✓" : "!" : "○"}</span><div><strong>{medicine.name}</strong><small>{medicine.detail}</small>{records[medicine.id]?.reason && <em>{records[medicine.id].reason}{records[medicine.id].note ? ` · ${records[medicine.id].note}` : ""}</em>}</div><time>{records[medicine.id]?.time || "Not recorded"}</time></article>)}</div></section>
        {prnRecorded && <section className="completion-block prn-completion"><div className="completion-block-title"><div><p className="round-eyebrow">PRN follow-up</p><h3>Paracetamol · {prnDose}</h3></div><span>Review due</span></div><p>Given for {prnReason} at {prnTime}. Pain score before administration: {prnScore}/10.</p><div><b>◷</b><span><strong>Effectiveness review due in 2 hours</strong><small>This task will remain open after this person is completed.</small></span></div></section>}
        <section className="completion-block"><div className="completion-block-title"><div><p className="round-eyebrow">Safety and follow-up</p><h3>Completion checks</h3></div></div><ul className="completion-checks"><li className={outstandingCount ? "blocked" : "passed"}><b>{outstandingCount ? "!" : "✓"}</b><span><strong>Every scheduled medicine has an outcome</strong><small>{outstandingCount ? `${outstandingCount} medicine${outstandingCount > 1 ? "s" : ""} still require recording.` : "All scheduled medicines have been recorded."}</small></span></li><li className={records[3]?.outcome === "Given" && !records[3]?.witness ? "blocked" : "passed"}><b>{records[3]?.outcome === "Given" && !records[3]?.witness ? "!" : "✓"}</b><span><strong>Controlled-drug witness</strong><small>{records[3]?.witness ? `Confirmed by ${records[3].witness}.` : records[3]?.outcome === "Given" ? "Witness confirmation is missing." : "No outstanding witness requirement."}</small></span></li><li className="passed"><b>✓</b><span><strong>Reasons and notes complete</strong><small>Every non-administration includes a factual reason.</small></span></li><li className={prnRecorded ? "attention" : "passed"}><b>{prnRecorded ? "◷" : "✓"}</b><span><strong>PRN effectiveness follow-up</strong><small>{prnRecorded ? "A timed review task will remain open after completion." : "No PRN follow-up is required."}</small></span></li></ul></section>
        <section className="signoff-card"><div><p className="round-eyebrow">Staff sign-off</p><h3>Precious O.</h3><span>Support worker · {now()}</span></div><label className={outstandingCount ? "disabled" : ""}><input type="checkbox" disabled={outstandingCount > 0} checked={completionConfirmed} onChange={(e) => setCompletionConfirmed(e.target.checked)} /><span><strong>I confirm this record is complete and accurate</strong><small>I have recorded each outcome immediately and reviewed all warnings and follow-up actions.</small></span></label></section>
        <footer className="complete-actions"><button onClick={() => setShowComplete(false)}>Return to medicines</button><button disabled={outstandingCount > 0 || !completionConfirmed} onClick={completePerson}>Sign off and complete person →</button></footer>
      </> : <div className="completion-success"><span>✓</span><p className="round-eyebrow">Person completed</p><h2>{person.name} is signed off</h2><p>The MAR, witness details and audit history have been saved. Any follow-up tasks remain visible to the team.</p><div><article><small>Completed by</small><strong>Precious O.</strong></article><article><small>Completed at</small><strong>{now()}</strong></article><article><small>Next person</small><strong>Jordan Taylor · 08:00</strong></article></div><button onClick={continueToNextPerson}>Continue to Jordan Taylor →</button><button className="back-dashboard" onClick={() => setShowComplete(false)}>Return to round</button></div>}
    </section></div>}
  </main>;
}
